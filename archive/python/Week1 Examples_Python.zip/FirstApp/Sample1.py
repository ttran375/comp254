# simple python function


def display(number):
    number = number*3
    print(number)
    # Now call the function we just defined:


display(10)


list1 = [2, 3, 4, 5]
print(list1)

