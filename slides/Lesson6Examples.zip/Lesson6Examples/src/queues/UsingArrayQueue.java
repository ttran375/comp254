package queues;

public class UsingArrayQueue {

	public static void main(String[] args) {
		// use an ArrayQueue, populate and use its methods
		ArrayQueue<String> queue = new ArrayQueue<String>(5);
		queue.enqueue("SEM1");
		queue.enqueue("SEM2");
		queue.enqueue("SEM3");
		queue.enqueue("SEM4");
		queue.enqueue("SEM5");
		//dequeue and print out
		
		

	}

}
